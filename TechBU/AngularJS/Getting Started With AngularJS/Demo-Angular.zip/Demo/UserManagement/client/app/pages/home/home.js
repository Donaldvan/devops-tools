app.controller("homeCtrl",[function(){
	var hc = this;
}]);