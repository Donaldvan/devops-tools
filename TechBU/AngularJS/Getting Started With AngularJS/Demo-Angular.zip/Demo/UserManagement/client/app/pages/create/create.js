app.controller("createCtrl",['$http',function($http){
	console.log("Inside Register Controller");
	var cc = this;
	cc.user ={};

	cc.create=function(){
		if(cc.user.password !== cc.user.confirmpassword){
			alert("Password and confirm password mismatch")
		} else {
			cc.user.id = "User-"+new Date().getTime();
			$http({'method':'POST','url':'/api/user/save','data':cc.user}).success(function(res){
				console.log("res",res);
				if(res.status === 200){
					alert("User information saved successfully.")
					cc.user ={};
				} else {
					alert("Error Occured");
				}
			}).error(function(err){
				alert("Error occured");
			});
		}
	}
	
}]);