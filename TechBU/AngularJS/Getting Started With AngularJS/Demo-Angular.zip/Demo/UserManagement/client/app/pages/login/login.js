app.controller("loginCtrl",['$location','$http',function($location,$http){
	var login = this;
	login.user = {};

	login.login=function(){
		$http({'method':'POST','url':'/api/user/login','data':login.user}).success(function(res){
				console.log("res",res);
				if(res.status === 200){
					$location.path('/home');
				} else {
					alert(res.data);
				}
			}).error(function(err){
				alert("Error occured");
			});
	}
}]);