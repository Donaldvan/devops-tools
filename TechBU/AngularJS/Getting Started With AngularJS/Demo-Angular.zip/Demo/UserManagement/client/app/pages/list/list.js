app.controller("listCtrl",['$http',function($http){
	var lc = this;
	lc.userList = [];

	$http({'method':'GET','url':'/api/user/list'}).success(function(res){
			if(res.status === 200){
				lc.userList = res.data;
			} else {
				alert("Error occured while fetching Data");
			}
		}).error(function(err){
				alert("Error occured");
		});

	lc.removeUser = function(data){
		$http({'method':'POST','url':'/api/user/delete','data':data}).success(function(res){
			if(res.status === 200){
				var index = lc.userList.indexOf(data);
				lc.userList.splice(index,1);
			} else {
				alert("Error occured while Deleting Data");
			}
		}).error(function(err){
				alert("Error occured");
		});	
	}


}]);