var app = angular.module("usermanagement",['ui.router']);

app.config(function($stateProvider,$urlRouterProvider){

	$urlRouterProvider.otherwise('/login');

	$urlRouterProvider.when('/home','/home/list');

	$stateProvider
		.state('login',{
			url : '/login',
			controller : "loginCtrl as login",
			templateUrl : 'client/app/pages/login/login.html'
		}).state('home',{
			url : '/home',
			controller : 'homeCtrl as hc',
			templateUrl : 'client/app/pages/home/home.html'
		}).state('home.list',{
			url : '/list',
			controller : 'listCtrl as lc',
			templateUrl : 'client/app/pages/list/list.html'
		}).state('home.create',{
			url : '/create',
			controller : 'createCtrl as cc',
			templateUrl : 'client/app/pages/create/create.html'
		});
});