var express = require('express');
var controller = require('./userController');

var router = express.Router();

router.get('/list',controller.get);
router.post('/save',controller.save);
router.post('/login',controller.login);
router.post('/delete',controller.deleteUser);

module.exports = router;