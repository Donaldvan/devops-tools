var User = require('./userModel');
var _ = require('lodash');

var seed = {
	"id" : "dummyID-1234",
	"firstname" : "",
	"lastname" : "",
	"username" : "admin",
	"dob" : "",
	"password" : "admin"
}

exports.storeSeedData = function(){
	User.create(seed,function(err,user){
		if(err){
			console.log("Error occured while creating seed data");
		} else{
			console.log("Seed created successfully");
		}		
	})	
}

exports.save = function(req,res){
	User.create(req.body,function(err,user){
		if(err){
			return res.json({status:500,data:err});
		}
		return res.json({status:200,data:user});
	})
}

exports.get = function(req,res){
	User.find({},function(err,users){
		if(err){
			return res.json({status:500,data:err});
		}
		return res.json({status:200,data:users});
	})
}

exports.login =function(req,res){
	User.findOne({'username':req.body.username},function(err,user){
		if(err){
			return res.json({status:500,data:err});
		} else if(!user){
			return res.json({status:500,data:"username mismatch"});
		}else{
			if(req.body.password === user.password){							
				return res.json({status:200,data:user});
			} else {
				return res.json({status:500,data:"Password mismatch"});
			}
		}	
	})
}

exports.deleteUser = function(req,res){
  User.remove({'id' :req.body.id}, function (err) {  	
    if (err) {
      res.json({status:500,data:err})
    }
    else {
      res.json({status:200,data:"Deleted"});
    }
  });
}

exports.update = function(req,res){
  User.findOne({'id' : req.body.id}, function (err, data) {
    if (err) {
      res.json(500, err)
    }
    else {
      var updated = _.merge(data, req.body);
      updated.save(function (err,obj) {
        	res.json(200,obj)
      });
    }
  });
}