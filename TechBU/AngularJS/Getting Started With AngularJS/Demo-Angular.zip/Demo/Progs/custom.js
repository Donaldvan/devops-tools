var app = angular.module("demo",[]);

app.controller("testCtrl",['$http',testCtrl])


function testCtrl($http){
	var tc = this;
	tc.name = "Edureka"

	tc.users = ["User-1","User-2","User-3","User-4","User-5"];

	tc.addUser = function(){
		tc.users.push(tc.name);
	}
}


app.controller("testCtrl2",[test2])

function test2(){
	var t2 = this;
	t2.name = "Hello"
}